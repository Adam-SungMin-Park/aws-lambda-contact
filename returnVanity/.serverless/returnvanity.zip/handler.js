'use strict';

const AWS = require('aws-sdk');
const ddb = new AWS.DynamoDB.DocumentClient({region:'us-west-2'});

module.exports.vanityReturn = async (event, context, callback) => {
  const requestId = context.awsRequestId;
  const number = event['Details']['ContactData']['CustomerEndpoint']['Address']
  const rawNum = number.split(1)[1];
  let vanityNumArray =[];
  let vanityNum = "";


  await createNumber(requestId,number).then(()=>{
    callback(null, {
      statusCode: 201,
      body:'',
      headers: {
        'Access-Control-Allow-Origin' : '*'
      }
    })
  }).catch((err)=>{
    console.error("error is" + err)
  });

};

function returnVanityNumber(number){
    const params = `
      select "vanity"
      FROM "VANITY_NUMBER"
      WHERE "customerNumber" = number
    `
    return ddb.get(params).promise();
}
